export interface Category{
    categoryName: string,
    catagoryId: number,
    id: number
}