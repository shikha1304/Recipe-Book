export interface User {
    name: string,
    email: string,
    password: string,
    registrationDate: Date
    id: number
}
