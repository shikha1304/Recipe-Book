export interface List{
    item: string,
    quantity: number,
    userId: number,
    id: number
}